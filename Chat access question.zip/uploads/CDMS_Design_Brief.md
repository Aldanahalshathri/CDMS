# CDMS — Clinical Data Management Solution (Interactive Prototype Brief)

Build a complete, working single-page web application: a **metadata registry / data element dictionary** for the Saudi Unified Health Record (UHR/NPHIES) ecosystem. It gives interoperability analysts and database teams one place to search any clinical data element and instantly see where it lives across every interface — its local name, full technical path, optionality, data type, and terminology binding.

All data is provided at the bottom of this brief as JSON. Embed it directly in the app — no backend, no external calls. The dataset is REAL (extracted from official NPHIES/CS-D10/FHIR/CDR specifications), so render it exactly as given; never invent or alter paths, optionality codes, or OIDs.

---

## Users & roles

Add a role switch in the top bar: **Viewer** (default) and **Admin**.
- **Viewer**: read-only — search, browse, filter, copy paths.
- **Admin**: everything Viewer can do, plus in-memory editing: change a mapping's optionality, edit element definitions, add a code to a value set, add a new element, and change element status (Draft → In Review → Approved → Deprecated). Edited items get a small "modified" indicator. No persistence needed — state only.

## Core views (left navigation)

1. **Search / Elements** (home). A prominent global search bar that matches across: canonical element name, definition, local names in every interface, full paths, parent containers, and value set names. Example: typing "PV1-19" or "encompassingEncounter" or "visit" must all find "Visit (Encounter) ID". Below it, the element list as cards or table rows showing: ID, canonical name, domain chip, data type, terminology-bound badge, status, and count of interface mappings. Filters: by Domain, by Interface, by Standard (HL7 v2 / CDA / FHIR R4 / Database), by Optionality, by terminology-bound.

2. **Element detail** (opens on click). Shows definition, domain, canonical data type, steward, status, value set link (if bound). Then the heart of the product: a **mappings table** — one row per interface where the element exists — with columns: Interface (with standard badge), Local Name, Parent, Full Path (monospace, with a copy-to-clipboard button), Optionality (color-coded chip), Cardinality, Data Type, Value Set, Source Reference, Notes. Interfaces where the element does NOT exist are listed collapsed/grayed at the bottom ("Not present in: …"). LDX and Patient Profile always show "Pending — Database team".

3. **Matrix**. A grid: 20 elements (rows) × interfaces (columns), each cell showing the full path (truncated with tooltip/expand) and an optionality chip. Sticky first column and header. A legend above. Clicking a cell opens the element detail scrolled to that interface.

4. **Value Sets**. List of the 11 value sets with name, OIDs (monospace), binding strength, total code count, description. Expanding one shows its codes (from valueSetCodes) plus a note when only samples are included, and a reverse list: "Used by elements: …" (derived from mappings/elements referencing that VS id). Admin can add a code.

5. **Interfaces**. Reference list of the 17 interfaces with standard badge, content description, path syntax rule, owning team. Clicking one filters the element list to elements mapped in it.

## Optionality color system (use everywhere, consistently)

- M / R → green (mandatory/required)
- R2 → blue (required if known)
- O → amber (optional)
- I / NP → gray (ignored / not permitted) — render with strikethrough-style muted text
- C or mixed rules like "M (Report) / NP (Order)" → orange (conditional)
Show the exact source code text inside the chip (e.g., "R2", "M (Generic) / NP (Compound)") — never normalize it.

## Design direction

Professional clinical-informatics tool, data-dense but calm. Palette: deep navy #1F4E5F as primary, teal #2E8B8B as accent, warm off-white background, the five optionality colors as the only other hues. Typography: a clean grotesque for UI (e.g., Inter/IBM Plex Sans), monospace (e.g., IBM Plex Mono/JetBrains Mono) for every path, OID, and code — paths are the product's raw material, treat them typographically like code. Standard badges: HL7 v2, CDA, FHIR R4, DB — each with a subtle distinct tint. Signature element: the search experience — results should highlight WHERE the match occurred (e.g., "matched path in IF-01 ADT: PV1-19.1"). English UI, LTR.

## Quality bar

Responsive down to tablet; keyboard focus visible; empty states with guidance ("No elements match — clear filters"); copy buttons give feedback ("Copied"). Fast client-side filtering, no loading spinners needed.

---

## DATA (embed as-is)

```json
{
 "domains": [
  {
   "id": "DOM-01",
   "name": "Patient Demographics",
   "description": "Identity, contact, personal characteristics"
  },
  {
   "id": "DOM-02",
   "name": "Encounter / Visit",
   "description": "Admissions, discharges, visit identifiers, patient class"
  },
  {
   "id": "DOM-03",
   "name": "Diagnoses & Problems",
   "description": "Coded diagnoses (ICD-10-AM), problem lists"
  },
  {
   "id": "DOM-04",
   "name": "Medications",
   "description": "Prescriptions, dispense records, drug coding"
  },
  {
   "id": "DOM-05",
   "name": "Laboratory & Observations",
   "description": "Lab orders/results, specimens, observation codes/values, vital signs"
  },
  {
   "id": "DOM-06",
   "name": "Radiology",
   "description": "Imaging orders, procedures, reports, accession numbers"
  },
  {
   "id": "DOM-07",
   "name": "Orders (Cross-domain)",
   "description": "Order identifiers, priority, status — shared by lab, radiology and other order types"
  },
  {
   "id": "DOM-08",
   "name": "Clinical Documents",
   "description": "Document metadata and narrative sections of CDA summaries"
  },
  {
   "id": "DOM-09",
   "name": "Provider & Organization",
   "description": "Practitioners, facilities, organizations and identifiers"
  },
  {
   "id": "DOM-10",
   "name": "Immunization",
   "description": "Vaccine administration records"
  },
  {
   "id": "DOM-11",
   "name": "Technical / Message Metadata",
   "description": "Message control IDs, timestamps, sender/receiver identifiers"
  }
 ],
 "interfaces": [
  {
   "id": "IF-01",
   "name": "ADT (Encounters)",
   "standard": "HL7 v2",
   "content": "ADT A01/A02/A03/A04/A08 etc. (CS-D10 v4.9beta2)",
   "pathSyntax": "SEG-Field.Component (e.g., PV1-19.1)",
   "owner": "Interoperability"
  },
  {
   "id": "IF-02",
   "name": "Vital Signs",
   "standard": "HL7 v2",
   "content": "ORU^R01 (ORU Vital Sign Spec 17-06-2025)",
   "pathSyntax": "SEG-Field.Component (e.g., OBX-5)",
   "owner": "Interoperability"
  },
  {
   "id": "IF-03",
   "name": "Clinical Notes & Summaries",
   "standard": "CDA",
   "content": "Discharge, Outpatient, Operative, Maternal & Newborn Discharge Summaries (CS-D10)",
   "pathSyntax": "Absolute XPath from ClinicalDocument",
   "owner": "Interoperability"
  },
  {
   "id": "IF-04",
   "name": "Laboratory Order",
   "standard": "CDA",
   "content": "Lab Order document (CS-D10)",
   "pathSyntax": "Absolute XPath from ClinicalDocument",
   "owner": "Interoperability"
  },
  {
   "id": "IF-05",
   "name": "Laboratory Result",
   "standard": "CDA",
   "content": "Lab Result document (CS-D10)",
   "pathSyntax": "Absolute XPath from ClinicalDocument",
   "owner": "Interoperability"
  },
  {
   "id": "IF-06",
   "name": "Radiology Order",
   "standard": "CDA",
   "content": "Rad Order document (CS-D10)",
   "pathSyntax": "Absolute XPath from ClinicalDocument",
   "owner": "Interoperability"
  },
  {
   "id": "IF-07",
   "name": "Radiology Result",
   "standard": "CDA",
   "content": "Rad Report document (CS-D10)",
   "pathSyntax": "Absolute XPath from ClinicalDocument",
   "owner": "Interoperability"
  },
  {
   "id": "IF-08",
   "name": "Medication Prescription",
   "standard": "FHIR R4",
   "content": "MedicationRequest bundle (Med Use Case 06-05-2025)",
   "pathSyntax": "FHIRPath",
   "owner": "Interoperability"
  },
  {
   "id": "IF-09",
   "name": "Medication Dispense",
   "standard": "FHIR R4",
   "content": "MedicationDispense bundle (Med Use Case 06-05-2025)",
   "pathSyntax": "FHIRPath",
   "owner": "Interoperability"
  },
  {
   "id": "IF-10",
   "name": "Lab Order (FHIR)",
   "standard": "FHIR R4",
   "content": "bundleLabOrder: Composition, ServiceRequest, Observation, Specimen, Patient, PractitionerRole, Practitioner, Organization (27-01-2026)",
   "pathSyntax": "FHIRPath",
   "owner": "Interoperability"
  },
  {
   "id": "IF-11",
   "name": "Lab Report (FHIR)",
   "standard": "FHIR R4",
   "content": "bundleLabReport: Composition, DiagnosticReport, Observation, ServiceRequest, Specimen, Device, Patient, PractitionerRole, Practitioner, Organization, Encounter (27-01-2026)",
   "pathSyntax": "FHIRPath",
   "owner": "Interoperability"
  },
  {
   "id": "IF-12",
   "name": "Rad Order (FHIR)",
   "standard": "FHIR R4",
   "content": "bundleRadOrder: Composition, ServiceRequest, Observation, Specimen, Patient, PractitionerRole, Practitioner, Organization (27-01-2026)",
   "pathSyntax": "FHIRPath",
   "owner": "Interoperability"
  },
  {
   "id": "IF-13",
   "name": "Rad Report (FHIR)",
   "standard": "FHIR R4",
   "content": "bundleRadReport: Composition, DiagnosticReport, ServiceRequest, ImagingStudy, Procedure, Patient, PractitionerRole, Practitioner, Organization, Device, Encounter, Specimen, DocumentReference, Binary, Endpoint (09-02-2026)",
   "pathSyntax": "FHIRPath",
   "owner": "Interoperability"
  },
  {
   "id": "IF-14",
   "name": "CDR (Clinical Data Repository)",
   "standard": "Database",
   "content": "Orion CDR — Demographics, Encounters, Providers & Organizations, Laboratory Results HDCs (Admin Manual v16)",
   "pathSyntax": "Schema.Table.column ('→' = FK to)",
   "owner": "Database Team"
  },
  {
   "id": "IF-15",
   "name": "LDX",
   "standard": "Database / Interface",
   "content": "TO BE DETAILED BY DATABASE TEAM — intentionally empty",
   "pathSyntax": "schema.table.column",
   "owner": "Database Team"
  },
  {
   "id": "IF-16",
   "name": "Patient Profile",
   "standard": "Database / Interface",
   "content": "TO BE DETAILED BY DATABASE TEAM — intentionally empty",
   "pathSyntax": "schema.table.column",
   "owner": "Database Team"
  },
  {
   "id": "IF-17",
   "name": "Immunization (FHIR)",
   "standard": "FHIR R4",
   "content": "Immunization message bundle: MessageHeader, Immunization, Patient, Practitioner, PractitionerRole, Organization, Encounter, Observation (30-06-2026)",
   "pathSyntax": "FHIRPath",
   "owner": "Interoperability"
  }
 ],
 "elements": [
  {
   "id": "CDM-0001",
   "name": "Patient Health ID",
   "definition": "National unique patient identifier (Health ID) from the NHIC Patient Registry; assigning authority OID 2.16.840.1.113883.3.3731.1.1.100.1.",
   "domain": "DOM-01",
   "dataType": "Identifier",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0002",
   "name": "Patient Date of Birth",
   "definition": "The patient's date (and optionally time) of birth.",
   "domain": "DOM-01",
   "dataType": "Date",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0003",
   "name": "Patient Name",
   "definition": "The name(s) of the patient; primary/legal name reported first.",
   "domain": "DOM-01",
   "dataType": "Structured/Complex",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0004",
   "name": "Patient Gender",
   "definition": "Administrative gender / biological sex of the patient.",
   "domain": "DOM-01",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-001",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0005",
   "name": "Visit (Encounter) ID",
   "definition": "Unique identifier of a patient visit/encounter; links all clinical activity to the encounter.",
   "domain": "DOM-02",
   "dataType": "Identifier",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0006",
   "name": "Patient Class (Encounter Class)",
   "definition": "Categorization of the encounter by care setting (Emergency, Inpatient, Outpatient…).",
   "domain": "DOM-02",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-002",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0007",
   "name": "Encounter Start (Admission) Date/Time",
   "definition": "Date/time the encounter started (admission / registration).",
   "domain": "DOM-02",
   "dataType": "DateTime",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0008",
   "name": "Encounter End (Discharge) Date/Time",
   "definition": "Date/time the encounter ended (discharge).",
   "domain": "DOM-02",
   "dataType": "DateTime",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0009",
   "name": "Diagnosis Code",
   "definition": "Coded diagnosis (KSA Principal Diagnosis — ICD-10-AM).",
   "domain": "DOM-03",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-010",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0010",
   "name": "Practitioner ID",
   "definition": "Identifier of the practitioner (attending / author / ordering / prescriber).",
   "domain": "DOM-09",
   "dataType": "Identifier",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0011",
   "name": "Healthcare Facility / Organization ID",
   "definition": "Identifier of the facility/organization (sending facility, encounter facility, resource organization).",
   "domain": "DOM-09",
   "dataType": "Identifier",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0012",
   "name": "Placer Order Number",
   "definition": "KSA-wide unique identifier assigned by the ordering system when the order was placed.",
   "domain": "DOM-07",
   "dataType": "Identifier",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0013",
   "name": "Filler Order Number / Accession Number",
   "definition": "Identifier assigned by the filler (lab/radiology) when tests/imaging performed.",
   "domain": "DOM-07",
   "dataType": "Identifier",
   "terminologyBound": "N",
   "valueSet": "",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0014",
   "name": "Order Priority",
   "definition": "Level of urgency of the order (A = ASAP, R = Routine).",
   "domain": "DOM-07",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-003",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0015",
   "name": "Order Status",
   "definition": "Current state of an order in its workflow.",
   "domain": "DOM-07",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-004",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0016",
   "name": "Diagnostic Report Status",
   "definition": "Current state of a diagnostic (lab/radiology) report.",
   "domain": "DOM-05",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-005",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0017",
   "name": "Observation Code",
   "definition": "Code identifying the observation/test performed (LOINC for vital signs).",
   "domain": "DOM-05",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-006",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0018",
   "name": "Observation Value",
   "definition": "The observed result value (type varies); units bound to VS-011 where applicable.",
   "domain": "DOM-05",
   "dataType": "Structured/Complex",
   "terminologyBound": "Y",
   "valueSet": "VS-011",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0019",
   "name": "Specimen Type",
   "definition": "The kind of biological sample collected (SNOMED CT).",
   "domain": "DOM-05",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-008",
   "steward": "Aldanah",
   "status": "Draft"
  },
  {
   "id": "CDM-0020",
   "name": "Medication Code (Prescribed / Dispensed Product)",
   "definition": "Code of the prescribed generic or dispensed medicinal product (SFDA / KSA Medication Registry).",
   "domain": "DOM-04",
   "dataType": "Coded",
   "terminologyBound": "Y",
   "valueSet": "VS-009",
   "steward": "Aldanah",
   "status": "Draft"
  }
 ],
 "mappings": [
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-01",
   "localName": "Patient Identifier List",
   "parent": "PID",
   "fullPath": "PID-3.1 (ID Number)",
   "optionality": "R",
   "cardinality": "1..*",
   "dataType": "CX",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT PID",
   "notes": "ID Number = Health ID from NHIC Patient Registry; Assigning Authority (PID-3.4) = 2.16.840.1.113883.3.3731.1.1.100.1 (ISO)"
  },
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-02",
   "localName": "Patient Identifier List",
   "parent": "PID",
   "fullPath": "PID-3.1 (ID Number)",
   "optionality": "R",
   "cardinality": "1..*",
   "dataType": "CX",
   "valueSet": "",
   "source": "ORU Vital Sign 17-06-2025 — PID",
   "notes": "Health ID as in ADT"
  },
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-03",
   "localName": "Patient identifier",
   "parent": "recordTarget",
   "fullPath": "ClinicalDocument/recordTarget/patientRole/id",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 2.3",
   "notes": "Same generic CDA header applies to Lab/Rad CDA documents (IF-04..07)"
  },
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-08",
   "localName": "Identifier of the Patient",
   "parent": "Patient",
   "fullPath": "Patient.identifier.value (system = HealthID OID)",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Patient",
   "notes": ""
  },
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-10",
   "localName": "Identifier of the Patient",
   "parent": "Patient",
   "fullPath": "Patient.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Lab Order 27-01-2026 — Patient (1.3.5)",
   "notes": ""
  },
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-11",
   "localName": "Identifier of the Patient",
   "parent": "Patient",
   "fullPath": "Patient.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Patient",
   "notes": ""
  },
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-17",
   "localName": "Identifier of the Patient",
   "parent": "Patient",
   "fullPath": "Patient.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Immunization 30-06-2026 — Patient",
   "notes": ""
  },
  {
   "elementId": "CDM-0001",
   "interfaceId": "IF-14",
   "localName": "Patient Identifier",
   "parent": "Patient",
   "fullPath": "Patient.patientIdentifierId → Identifier.Identifier + Identifier.LK_Namespace",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "FK / VARCHAR(50,250)",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Demographics HDC (PID-3)",
   "notes": "Identifier matching configured primary identifier type"
  },
  {
   "elementId": "CDM-0002",
   "interfaceId": "IF-01",
   "localName": "Date/Time of Birth",
   "parent": "PID",
   "fullPath": "PID-7",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "TS",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT PID",
   "notes": "Format YYYYMMDD"
  },
  {
   "elementId": "CDM-0002",
   "interfaceId": "IF-02",
   "localName": "Date/Time of Birth",
   "parent": "PID",
   "fullPath": "PID-7",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "TS",
   "valueSet": "",
   "source": "ORU Vital Sign 17-06-2025 — PID",
   "notes": "Format YYYYMMDD"
  },
  {
   "elementId": "CDM-0002",
   "interfaceId": "IF-03",
   "localName": "Patient Birth Time",
   "parent": "recordTarget",
   "fullPath": "ClinicalDocument/recordTarget/patientRole/patient/birthTime",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "TS",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 2.8",
   "notes": ""
  },
  {
   "elementId": "CDM-0002",
   "interfaceId": "IF-08",
   "localName": "Patient Birth Date",
   "parent": "Patient",
   "fullPath": "Patient.birthDate",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "date",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Patient",
   "notes": ""
  },
  {
   "elementId": "CDM-0002",
   "interfaceId": "IF-10",
   "localName": "Patient Birth Date",
   "parent": "Patient",
   "fullPath": "Patient.birthDate",
   "optionality": "I",
   "cardinality": "[0..0]",
   "dataType": "date",
   "valueSet": "",
   "source": "FHIR Lab Order 27-01-2026 — Patient",
   "notes": "IGNORED — demographics resolved from national registry"
  },
  {
   "elementId": "CDM-0002",
   "interfaceId": "IF-11",
   "localName": "Patient Birth Date",
   "parent": "Patient",
   "fullPath": "Patient.birthDate",
   "optionality": "I",
   "cardinality": "[0..0]",
   "dataType": "date",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Patient",
   "notes": "IGNORED"
  },
  {
   "elementId": "CDM-0002",
   "interfaceId": "IF-14",
   "localName": "Birth Date/Time",
   "parent": "Patient",
   "fullPath": "Patient.birthDateTimeUTC0 (+ birthDTUTC0OffsetMin, birthDTPrecisionId)",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "DATETIME",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Demographics HDC (PID-7)",
   "notes": ""
  },
  {
   "elementId": "CDM-0003",
   "interfaceId": "IF-01",
   "localName": "Patient Name",
   "parent": "PID",
   "fullPath": "PID-5 (Family=PID-5.1.1, Given=PID-5.2)",
   "optionality": "O",
   "cardinality": "0..*",
   "dataType": "XPN",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT PID",
   "notes": "If provided, Family Name/Surname and Given Name SHALL be present"
  },
  {
   "elementId": "CDM-0003",
   "interfaceId": "IF-03",
   "localName": "Patient Name",
   "parent": "recordTarget",
   "fullPath": "ClinicalDocument/recordTarget/patientRole/patient/name",
   "optionality": "O",
   "cardinality": "[0..*]",
   "dataType": "PN",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 2.6",
   "notes": ""
  },
  {
   "elementId": "CDM-0003",
   "interfaceId": "IF-08",
   "localName": "Name of the Patient",
   "parent": "Patient",
   "fullPath": "Patient.name",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "HumanName",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Patient",
   "notes": ""
  },
  {
   "elementId": "CDM-0003",
   "interfaceId": "IF-10",
   "localName": "Name of the Patient",
   "parent": "Patient",
   "fullPath": "Patient.name",
   "optionality": "I",
   "cardinality": "[0..0]",
   "dataType": "HumanName",
   "valueSet": "",
   "source": "FHIR Lab Order 27-01-2026 — Patient",
   "notes": "IGNORED"
  },
  {
   "elementId": "CDM-0003",
   "interfaceId": "IF-11",
   "localName": "Name of the Patient",
   "parent": "Patient",
   "fullPath": "Patient.name",
   "optionality": "I",
   "cardinality": "[0..0]",
   "dataType": "HumanName",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Patient",
   "notes": "IGNORED"
  },
  {
   "elementId": "CDM-0003",
   "interfaceId": "IF-14",
   "localName": "Patient Name",
   "parent": "PatientName",
   "fullPath": "PatientName.firstName + PatientName.middleName + PatientName.surname",
   "optionality": "O",
   "cardinality": "0..*",
   "dataType": "VARCHAR(100)",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Demographics HDC (PID-5)",
   "notes": "First name in list also stored on Patient table preferred-name columns"
  },
  {
   "elementId": "CDM-0004",
   "interfaceId": "IF-01",
   "localName": "Administrative Sex",
   "parent": "PID",
   "fullPath": "PID-8",
   "optionality": "I",
   "cardinality": "0..1",
   "dataType": "IS",
   "valueSet": "VS-001",
   "source": "CS-D10 v4.9beta2 — ADT PID",
   "notes": "IGNORED by nphies if sent"
  },
  {
   "elementId": "CDM-0004",
   "interfaceId": "IF-03",
   "localName": "Patient Gender",
   "parent": "recordTarget",
   "fullPath": "ClinicalDocument/recordTarget/patientRole/patient/administrativeGenderCode",
   "optionality": "O",
   "cardinality": "[0..1]",
   "dataType": "CE",
   "valueSet": "VS-001",
   "source": "CS-D10 v4.9beta2 — CDA Header 2.7",
   "notes": ""
  },
  {
   "elementId": "CDM-0004",
   "interfaceId": "IF-08",
   "localName": "Patient Gender",
   "parent": "Patient",
   "fullPath": "Patient.gender",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-001",
   "source": "Med Use Case 06-05-2025 — Patient",
   "notes": ""
  },
  {
   "elementId": "CDM-0004",
   "interfaceId": "IF-10",
   "localName": "Patient Gender",
   "parent": "Patient",
   "fullPath": "Patient.gender",
   "optionality": "I",
   "cardinality": "[0..0]",
   "dataType": "code",
   "valueSet": "VS-001",
   "source": "FHIR Lab Order 27-01-2026 — Patient",
   "notes": "IGNORED"
  },
  {
   "elementId": "CDM-0004",
   "interfaceId": "IF-11",
   "localName": "Patient Gender",
   "parent": "Patient",
   "fullPath": "Patient.gender",
   "optionality": "I",
   "cardinality": "[0..0]",
   "dataType": "code",
   "valueSet": "VS-001",
   "source": "FHIR Lab Report 27-01-2026 — Patient",
   "notes": "IGNORED"
  },
  {
   "elementId": "CDM-0004",
   "interfaceId": "IF-14",
   "localName": "Gender",
   "parent": "Patient",
   "fullPath": "Patient.genderId → Gender lookup",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "FK",
   "valueSet": "VS-001",
   "source": "CDR Admin Manual v16 — Demographics HDC (PID-8)",
   "notes": ""
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-01",
   "localName": "Visit Number",
   "parent": "PV1",
   "fullPath": "PV1-19.1 (ID Number)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "CX",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT PV1",
   "notes": "Unique per patient visit; assigning authority strongly recommended"
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-02",
   "localName": "Visit Number",
   "parent": "PV1",
   "fullPath": "PV1-19.1 (ID Number)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "CX",
   "valueSet": "",
   "source": "ORU Vital Sign 17-06-2025 — PV1",
   "notes": ""
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-03",
   "localName": "Patient Encounter Identifier",
   "parent": "encompassingEncounter",
   "fullPath": "ClinicalDocument/componentOf/encompassingEncounter/id",
   "optionality": "R",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 11.3",
   "notes": "encompassingEncounter container itself is O [0..1]"
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-08",
   "localName": "Identifier of the Encounter",
   "parent": "Encounter",
   "fullPath": "Encounter.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Encounter",
   "notes": "Referenced via MedicationRequest.encounter (R2 [0..1])"
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-11",
   "localName": "Identifier of the Encounter",
   "parent": "Encounter",
   "fullPath": "Encounter.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Encounter",
   "notes": "Referenced via DiagnosticReport.encounter (R2 [0..1])"
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-13",
   "localName": "Identifier of the Encounter",
   "parent": "Encounter",
   "fullPath": "Encounter.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Rad Report 09-02-2026 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-17",
   "localName": "Identifier of the Encounter",
   "parent": "Encounter",
   "fullPath": "Encounter.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Immunization 30-06-2026 — Encounter",
   "notes": "Referenced via Immunization.encounter (R2 [0..1])"
  },
  {
   "elementId": "CDM-0005",
   "interfaceId": "IF-14",
   "localName": "Encounter External Identifier",
   "parent": "Encounter.PatientEncounter",
   "fullPath": "Encounter.PatientEncounter.externalIdentifier + externalIdentifierNSId → Identifier.LK_Namespace",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "VARCHAR(50,250)",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Encounters HDC (PV1-19)",
   "notes": "Identifier + Namespace unique across all patients"
  },
  {
   "elementId": "CDM-0006",
   "interfaceId": "IF-01",
   "localName": "Patient Class",
   "parent": "PV1",
   "fullPath": "PV1-2",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "IS",
   "valueSet": "VS-002",
   "source": "CS-D10 v4.9beta2 — ADT PV1",
   "notes": "E / I / O / D … out of HL7 Patient Class value set"
  },
  {
   "elementId": "CDM-0006",
   "interfaceId": "IF-02",
   "localName": "Patient Class",
   "parent": "PV1",
   "fullPath": "PV1-2",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "IS",
   "valueSet": "VS-002",
   "source": "ORU Vital Sign 17-06-2025 — PV1",
   "notes": ""
  },
  {
   "elementId": "CDM-0006",
   "interfaceId": "IF-03",
   "localName": "Encounter code",
   "parent": "encompassingEncounter",
   "fullPath": "ClinicalDocument/componentOf/encompassingEncounter/code",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CE",
   "valueSet": "VS-002",
   "source": "CS-D10 v4.9beta2 — CDA Header 11.4",
   "notes": ""
  },
  {
   "elementId": "CDM-0006",
   "interfaceId": "IF-08",
   "localName": "Encounter code",
   "parent": "Encounter",
   "fullPath": "Encounter.class",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Coding",
   "valueSet": "VS-002",
   "source": "Med Use Case 06-05-2025 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0006",
   "interfaceId": "IF-11",
   "localName": "Encounter code",
   "parent": "Encounter",
   "fullPath": "Encounter.class",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Coding",
   "valueSet": "VS-002",
   "source": "FHIR Lab Report 27-01-2026 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0006",
   "interfaceId": "IF-14",
   "localName": "Patient Class",
   "parent": "Encounter.PatientEncounter",
   "fullPath": "Encounter.PatientEncounter.patientClassId → Encounter.LK_PatientClass (drives encounterTypeId)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "FK / VARCHAR(50)",
   "valueSet": "VS-002",
   "source": "CDR Admin Manual v16 — Encounters HDC (PV1-2)",
   "notes": "E=EMERGENCY, I=INPATIENT, O=OUTPATIENT, P=PREADMIT, R=RECURRING_PATIENT, B=OBSTETRICS"
  },
  {
   "elementId": "CDM-0007",
   "interfaceId": "IF-01",
   "localName": "Admit Date/Time",
   "parent": "PV1",
   "fullPath": "PV1-44",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "TS",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT PV1",
   "notes": "SHALL be provided IF KNOWN; precision includes time"
  },
  {
   "elementId": "CDM-0007",
   "interfaceId": "IF-03",
   "localName": "Encounter start",
   "parent": "encompassingEncounter",
   "fullPath": "ClinicalDocument/componentOf/encompassingEncounter/effectiveTime/low",
   "optionality": "R",
   "cardinality": "[1..1]",
   "dataType": "TS",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 11.6",
   "notes": ""
  },
  {
   "elementId": "CDM-0007",
   "interfaceId": "IF-08",
   "localName": "Encounter start",
   "parent": "Encounter",
   "fullPath": "Encounter.period.start",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "dateTime",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0007",
   "interfaceId": "IF-11",
   "localName": "Encounter start",
   "parent": "Encounter",
   "fullPath": "Encounter.period.start",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "dateTime",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0007",
   "interfaceId": "IF-17",
   "localName": "Encounter start",
   "parent": "Encounter",
   "fullPath": "Encounter.period.start",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "dateTime",
   "valueSet": "",
   "source": "FHIR Immunization 30-06-2026 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0007",
   "interfaceId": "IF-14",
   "localName": "Admit Date/Time",
   "parent": "Encounter.PatientEncounter",
   "fullPath": "Encounter.PatientEncounter.admitDTUTC0 (+ OffsetMin, PrecisionId)",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "DATETIME",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Encounters HDC (PV1-44)",
   "notes": ""
  },
  {
   "elementId": "CDM-0008",
   "interfaceId": "IF-01",
   "localName": "Discharge Date/Time",
   "parent": "PV1",
   "fullPath": "PV1-45",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "TS",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT PV1",
   "notes": "SHALL be provided IF KNOWN"
  },
  {
   "elementId": "CDM-0008",
   "interfaceId": "IF-03",
   "localName": "Encounter end",
   "parent": "encompassingEncounter",
   "fullPath": "ClinicalDocument/componentOf/encompassingEncounter/effectiveTime/high",
   "optionality": "R2",
   "cardinality": "[0..1]",
   "dataType": "TS",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 11.7",
   "notes": ""
  },
  {
   "elementId": "CDM-0008",
   "interfaceId": "IF-08",
   "localName": "Encounter end",
   "parent": "Encounter",
   "fullPath": "Encounter.period.end",
   "optionality": "R2",
   "cardinality": "[0..1]",
   "dataType": "dateTime",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0008",
   "interfaceId": "IF-11",
   "localName": "Encounter end",
   "parent": "Encounter",
   "fullPath": "Encounter.period.end",
   "optionality": "R2",
   "cardinality": "[0..1]",
   "dataType": "dateTime",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Encounter",
   "notes": ""
  },
  {
   "elementId": "CDM-0008",
   "interfaceId": "IF-14",
   "localName": "Discharge Date/Time",
   "parent": "Encounter.PatientEncounter",
   "fullPath": "Encounter.PatientEncounter.dischargeDTUTC0 (+ OffsetMin, PrecisionId)",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "DATETIME",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Encounters HDC (PV1-45)",
   "notes": ""
  },
  {
   "elementId": "CDM-0009",
   "interfaceId": "IF-01",
   "localName": "Diagnosis Code",
   "parent": "DG1",
   "fullPath": "DG1-3.1 (Identifier)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "CE",
   "valueSet": "VS-010",
   "source": "CS-D10 v4.9beta2 — ADT DG1",
   "notes": "Out of Principal Diagnosis value set (ICD-10-AM)"
  },
  {
   "elementId": "CDM-0009",
   "interfaceId": "IF-03",
   "localName": "Diagnosis Code (Problem Entry)",
   "parent": "Problem Observation",
   "fullPath": "ClinicalDocument/component/structuredBody/component/section/entry[templateId/@root='2.16.840.1.113883.3.3731.1.210.100.43']/act/entryRelationship/observation[templateId/@root='2.16.840.1.113883.3.3731.1.210.100.44']/value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CD",
   "valueSet": "VS-010",
   "source": "CS-D10 v4.9beta2 — CDA Body: Problem Entry 2.12",
   "notes": "xsi:type='CD'; if no diagnosis observed: @code='160245001' (SNOMED)"
  },
  {
   "elementId": "CDM-0009",
   "interfaceId": "IF-14",
   "localName": "Encounter Diagnosis",
   "parent": "Encounter.PatientEncounterDiagnosis",
   "fullPath": "Encounter.PatientEncounterDiagnosis.diagnosisId → Encounter.LK_EncounterDiagnosis (free text: diagnosisFreeText)",
   "optionality": "O",
   "cardinality": "0..*",
   "dataType": "FK / text",
   "valueSet": "VS-010",
   "source": "CDR Admin Manual v16 — Encounters HDC (DG1-3)",
   "notes": ""
  },
  {
   "elementId": "CDM-0010",
   "interfaceId": "IF-01",
   "localName": "Attending Doctor",
   "parent": "PV1",
   "fullPath": "PV1-7.1 (ID Number)",
   "optionality": "R (ADT^A01) / O (other)",
   "cardinality": "0..*",
   "dataType": "XCN",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT PV1",
   "notes": "Legal name in first repetition"
  },
  {
   "elementId": "CDM-0010",
   "interfaceId": "IF-02",
   "localName": "Ordering Provider",
   "parent": "OBR",
   "fullPath": "OBR-16.1 (ID Number)",
   "optionality": "R2",
   "cardinality": "0..*",
   "dataType": "XCN",
   "valueSet": "",
   "source": "ORU Vital Sign 17-06-2025 — OBR",
   "notes": "PV1-7 is IGNORED in Vital Signs"
  },
  {
   "elementId": "CDM-0010",
   "interfaceId": "IF-03",
   "localName": "Author Identifier",
   "parent": "author",
   "fullPath": "ClinicalDocument/author/assignedAuthor/id",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 3.5",
   "notes": ""
  },
  {
   "elementId": "CDM-0010",
   "interfaceId": "IF-08",
   "localName": "Identifier of the Practitioner",
   "parent": "Practitioner",
   "fullPath": "Practitioner.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Practitioner",
   "notes": "Prescriber via MedicationRequest.requester"
  },
  {
   "elementId": "CDM-0010",
   "interfaceId": "IF-11",
   "localName": "Identifier of the Practitioner",
   "parent": "Practitioner",
   "fullPath": "Practitioner.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Practitioner",
   "notes": "Practitioner.name IGNORED [0..0]"
  },
  {
   "elementId": "CDM-0010",
   "interfaceId": "IF-14",
   "localName": "Provider Identifier",
   "parent": "Provider",
   "fullPath": "Provider.providerIdentifierId → Identifier / LK_Namespace",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "FK / VARCHAR(50,250)",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Providers & Organizations HDC (PV1-7.1)",
   "notes": "Names: Provider.prefNameFamilyName / prefNameGivenName"
  },
  {
   "elementId": "CDM-0011",
   "interfaceId": "IF-01",
   "localName": "Sending Facility",
   "parent": "MSH",
   "fullPath": "MSH-4.2 (Universal ID)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "HD",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — ADT MSH",
   "notes": ""
  },
  {
   "elementId": "CDM-0011",
   "interfaceId": "IF-02",
   "localName": "Sending Facility",
   "parent": "MSH",
   "fullPath": "MSH-4.2 (Universal ID)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "HD",
   "valueSet": "",
   "source": "ORU Vital Sign 17-06-2025 — MSH",
   "notes": ""
  },
  {
   "elementId": "CDM-0011",
   "interfaceId": "IF-03",
   "localName": "Encounter Healthcare Facility Identifier",
   "parent": "encompassingEncounter",
   "fullPath": "ClinicalDocument/componentOf/encompassingEncounter/location/healthCareFacility/id",
   "optionality": "R",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — CDA Header 11.9",
   "notes": "Author org id at ClinicalDocument/author/assignedAuthor/representedOrganization/id (M)"
  },
  {
   "elementId": "CDM-0011",
   "interfaceId": "IF-08",
   "localName": "Identifier of the Organization",
   "parent": "Organization",
   "fullPath": "Organization.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "Med Use Case 06-05-2025 — Organization",
   "notes": ""
  },
  {
   "elementId": "CDM-0011",
   "interfaceId": "IF-11",
   "localName": "Identifier of the Organization",
   "parent": "Organization",
   "fullPath": "Organization.identifier.value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Organization",
   "notes": "Organization.name IGNORED [0..0]"
  },
  {
   "elementId": "CDM-0011",
   "interfaceId": "IF-14",
   "localName": "Authoring Source",
   "parent": "Encounter.PatientEncounter",
   "fullPath": "Encounter.PatientEncounter.authoringSourceId → Identifier.Identifier / Identifier.LK_Namespace",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "FK / VARCHAR(50)",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Encounters HDC (MSH-4)",
   "notes": "If MSH-4 empty, EVN-7 used instead"
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-02",
   "localName": "Placer Order Number",
   "parent": "OBR",
   "fullPath": "OBR-2.1 (Entity Identifier)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "EI",
   "valueSet": "",
   "source": "ORU Vital Sign 17-06-2025 — OBR",
   "notes": ""
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-04",
   "localName": "Placer Order Number",
   "parent": "documentationOf/serviceEvent",
   "fullPath": "ClinicalDocument/documentationOf[1]/serviceEvent/id",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — Lab Order CDA 3.3",
   "notes": "KSA-Wide Placer Order Number; also in XDS referenceIdList (urn:ihe:iti:xds:2013:order)"
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-05",
   "localName": "Placer Order Number",
   "parent": "inFulfillmentOf/order",
   "fullPath": "ClinicalDocument/inFulfillmentOf/order/id[1]",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — Lab Result CDA 5.4",
   "notes": ""
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-06",
   "localName": "Placer Order Number",
   "parent": "documentationOf/serviceEvent",
   "fullPath": "ClinicalDocument/documentationOf[1]/serviceEvent/id",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — Rad Order CDA 3.3",
   "notes": ""
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-07",
   "localName": "Placer Order Number",
   "parent": "inFulfillmentOf/order",
   "fullPath": "ClinicalDocument/inFulfillmentOf/order/id[1]",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — Rad Report CDA 6.4",
   "notes": ""
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-10",
   "localName": "Placer Order Number",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.identifier",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Lab Order 27-01-2026 — Service Request (1.3.2)",
   "notes": ""
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-12",
   "localName": "Placer Order Number",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.identifier",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Rad Order 27-01-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-13",
   "localName": "Placer Order Number",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.identifier",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Rad Report 09-02-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0012",
   "interfaceId": "IF-14",
   "localName": "Placer Order Number",
   "parent": "LaboratoryResultPanel",
   "fullPath": "LaboratoryResultPanel.placerOrderNumber (+ NSId); micro: MicroResultAnalysis.placerOrderNumber",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "VARCHAR(250)",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Laboratory Results HDC (OBR-2)",
   "notes": "Can be null"
  },
  {
   "elementId": "CDM-0013",
   "interfaceId": "IF-02",
   "localName": "Filler Order Number",
   "parent": "OBR",
   "fullPath": "OBR-3.1 (Entity Identifier)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "EI",
   "valueSet": "",
   "source": "ORU Vital Sign 17-06-2025 — OBR",
   "notes": ""
  },
  {
   "elementId": "CDM-0013",
   "interfaceId": "IF-05",
   "localName": "Filler Order Number",
   "parent": "inFulfillmentOf/order",
   "fullPath": "ClinicalDocument/inFulfillmentOf/order/id[2]",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — Lab Result CDA 5.5",
   "notes": "Assigned by the laboratory (accession number)"
  },
  {
   "elementId": "CDM-0013",
   "interfaceId": "IF-07",
   "localName": "Accession Number(s)",
   "parent": "inFulfillmentOf/order",
   "fullPath": "ClinicalDocument/inFulfillmentOf/order/ps3-20:accessionNumber",
   "optionality": "M",
   "cardinality": "[1..*]",
   "dataType": "II",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — Rad Report CDA / XDS referenceIdList",
   "notes": "Semantic link to KOS manifests (urn:ihe:iti:xds:2013:accession)"
  },
  {
   "elementId": "CDM-0013",
   "interfaceId": "IF-13",
   "localName": "Filler Order Number / Accession Number",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.identifier",
   "optionality": "M (Report) / NP (Order)",
   "cardinality": "[1..1] / [0..0]",
   "dataType": "Identifier",
   "valueSet": "",
   "source": "FHIR Rad Report 09-02-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0013",
   "interfaceId": "IF-14",
   "localName": "Filler Order Number",
   "parent": "LaboratoryResultPanel",
   "fullPath": "LaboratoryResultPanel.fillerOrderNumber (+ NSId); micro: MicroResultAnalysis.fillerOrderNumber",
   "optionality": "C",
   "cardinality": "0..1",
   "dataType": "VARCHAR(250)",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Laboratory Results HDC (OBR-3)",
   "notes": "Required in either ORC or OBR; must match when in both"
  },
  {
   "elementId": "CDM-0014",
   "interfaceId": "IF-04",
   "localName": "Ordered Test Priority",
   "parent": "Lab Order Data Processing Entry",
   "fullPath": "ClinicalDocument/component/structuredBody/component/section/entry[templateId/@root='2.16.840.1.113883.3.3731.1.105.3']/act/priorityCode",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CE",
   "valueSet": "VS-003",
   "source": "CS-D10 v4.9beta2 — Lab Order CDA 3.5",
   "notes": ""
  },
  {
   "elementId": "CDM-0014",
   "interfaceId": "IF-10",
   "localName": "Ordered Test Priority",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.priority",
   "optionality": "R",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-003",
   "source": "FHIR Lab Order 27-01-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0014",
   "interfaceId": "IF-12",
   "localName": "Ordered Test Priority",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.priority",
   "optionality": "R",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-003",
   "source": "FHIR Rad Order 27-01-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0014",
   "interfaceId": "IF-13",
   "localName": "Ordered Test Priority",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.priority",
   "optionality": "R",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-003",
   "source": "FHIR Rad Report 09-02-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0015",
   "interfaceId": "IF-04",
   "localName": "Order Status",
   "parent": "documentationOf/serviceEvent",
   "fullPath": "ClinicalDocument/documentationOf[1]/serviceEvent/nphies:workflowStatusCode",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CS",
   "valueSet": "VS-004",
   "source": "CS-D10 v4.9beta2 — Lab Order CDA 3.4",
   "notes": ""
  },
  {
   "elementId": "CDM-0015",
   "interfaceId": "IF-10",
   "localName": "Request status",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.status",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-004",
   "source": "FHIR Lab Order 27-01-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0015",
   "interfaceId": "IF-12",
   "localName": "Request status",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.status",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-004",
   "source": "FHIR Rad Order 27-01-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0015",
   "interfaceId": "IF-13",
   "localName": "Request status",
   "parent": "ServiceRequest",
   "fullPath": "ServiceRequest.status",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-004",
   "source": "FHIR Rad Report 09-02-2026 — Service Request",
   "notes": ""
  },
  {
   "elementId": "CDM-0016",
   "interfaceId": "IF-11",
   "localName": "Diagnostic Report Status",
   "parent": "DiagnosticReport",
   "fullPath": "DiagnosticReport.status",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-005",
   "source": "FHIR Lab Report 27-01-2026 — Diagnostic Report",
   "notes": ""
  },
  {
   "elementId": "CDM-0016",
   "interfaceId": "IF-13",
   "localName": "Diagnostic Report Status",
   "parent": "DiagnosticReport",
   "fullPath": "DiagnosticReport.status",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "code",
   "valueSet": "VS-005",
   "source": "FHIR Rad Report 09-02-2026 — Diagnostic Report",
   "notes": ""
  },
  {
   "elementId": "CDM-0016",
   "interfaceId": "IF-14",
   "localName": "Result (Report) Status",
   "parent": "LaboratoryResultPanel",
   "fullPath": "LaboratoryResultPanel.resultStatusId → LaboratoryResultStatus.code",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "FK / VARCHAR(50)",
   "valueSet": "VS-005",
   "source": "CDR Admin Manual v16 — Laboratory Results HDC (OBR-25)",
   "notes": "When null, derived from statuses of results within report"
  },
  {
   "elementId": "CDM-0017",
   "interfaceId": "IF-02",
   "localName": "Observation Identifier",
   "parent": "OBX",
   "fullPath": "OBX-3.1 (Identifier)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "CE",
   "valueSet": "VS-006",
   "source": "ORU Vital Sign 17-06-2025 — OBX",
   "notes": "LOINC code from CS-Obs-VitalSign"
  },
  {
   "elementId": "CDM-0017",
   "interfaceId": "IF-03",
   "localName": "Vital Signs Observation Code",
   "parent": "Vital Signs Observation",
   "fullPath": "ClinicalDocument/component/structuredBody/component/section/entry[templateId='2.16.840.1.113883.3.3731.1.210.100.54']/organizer/component/observation[templateId/@root='2.16.840.1.113883.3.3731.1.210.100.55']/code",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CE",
   "valueSet": "VS-006",
   "source": "CS-D10 v4.9beta2 — CDA Body: Vital Signs Observation 11.7",
   "notes": "LOINC vital sign codes"
  },
  {
   "elementId": "CDM-0017",
   "interfaceId": "IF-05",
   "localName": "Observation Code",
   "parent": "Laboratory Observation",
   "fullPath": "ClinicalDocument/component/structuredBody/component/section/entry[templateId/@root='2.16.840.1.113883.3.3731.1.105.9']/act/entryRelationship/observation[templateId/@root='2.16.840.1.113883.3.3731.1.105.16']/code",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CE",
   "valueSet": "",
   "source": "CS-D10 v4.9beta2 — Lab Result CDA 6.5",
   "notes": "May also sit inside Battery Organizer (…/organizer[templateId/@root='…105.15']/component/observation) or Isolate Organizer (…105.17)"
  },
  {
   "elementId": "CDM-0017",
   "interfaceId": "IF-11",
   "localName": "Observation Code",
   "parent": "Observation",
   "fullPath": "Observation.code",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CodeableConcept",
   "valueSet": "",
   "source": "FHIR Lab Report 27-01-2026 — Observation",
   "notes": ""
  },
  {
   "elementId": "CDM-0017",
   "interfaceId": "IF-14",
   "localName": "Laboratory Test Code",
   "parent": "LaboratoryTest",
   "fullPath": "LaboratoryTest.code (+ codingSystem, description)",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "VARCHAR",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Laboratory Results HDC (OBX-3)",
   "notes": "Code > 100 chars with no coding system is treated as textual"
  },
  {
   "elementId": "CDM-0018",
   "interfaceId": "IF-02",
   "localName": "Observation Value",
   "parent": "OBX",
   "fullPath": "OBX-5",
   "optionality": "R",
   "cardinality": "1..1",
   "dataType": "Varies (per OBX-2: NM=16, ST=199)",
   "valueSet": "VS-011",
   "source": "ORU Vital Sign 17-06-2025 — OBX",
   "notes": "Units in OBX-6 (R2) — UCUM / CS-Lab-ObservationUnit"
  },
  {
   "elementId": "CDM-0018",
   "interfaceId": "IF-03",
   "localName": "Vital Sign Value",
   "parent": "Vital Signs Observation",
   "fullPath": "ClinicalDocument/component/structuredBody/component/section/entry[templateId='2.16.840.1.113883.3.3731.1.210.100.54']/organizer/component/observation[templateId/@root='2.16.840.1.113883.3.3731.1.210.100.55']/value",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "PQ",
   "valueSet": "VS-011",
   "source": "CS-D10 v4.9beta2 — CDA Body: Vital Signs Observation 11.10",
   "notes": "xsi:type='PQ'"
  },
  {
   "elementId": "CDM-0018",
   "interfaceId": "IF-05",
   "localName": "Observation Value",
   "parent": "Laboratory Observation",
   "fullPath": "ClinicalDocument/component/structuredBody/component/section/entry[templateId/@root='2.16.840.1.113883.3.3731.1.105.9']/act/entryRelationship/observation[templateId/@root='2.16.840.1.113883.3.3731.1.105.16']/value",
   "optionality": "R",
   "cardinality": "[1..1]",
   "dataType": "Varies (xsi:type)",
   "valueSet": "VS-011",
   "source": "CS-D10 v4.9beta2 — Lab Result CDA 6.8",
   "notes": ""
  },
  {
   "elementId": "CDM-0018",
   "interfaceId": "IF-11",
   "localName": "Observation Value",
   "parent": "Observation",
   "fullPath": "Observation.value[x]",
   "optionality": "NP (hasMember) / M (otherwise)",
   "cardinality": "[0..0] / [1..1]",
   "dataType": "value[x]",
   "valueSet": "VS-011",
   "source": "FHIR Lab Report 27-01-2026 — Observation",
   "notes": ""
  },
  {
   "elementId": "CDM-0018",
   "interfaceId": "IF-14",
   "localName": "Result Value",
   "parent": "SingleResult / LaboratoryResult",
   "fullPath": "SingleResult / MicroResult / TextualResult / ReflexResult result columns; LaboratoryResult.code/description/codingSystem",
   "optionality": "R2",
   "cardinality": "0..1",
   "dataType": "Varies",
   "valueSet": "",
   "source": "CDR Admin Manual v16 — Laboratory Results HDC (OBX-5)",
   "notes": "Target table depends on result type (OBX-2) and report kind"
  },
  {
   "elementId": "CDM-0019",
   "interfaceId": "IF-05",
   "localName": "Specimen Type",
   "parent": "Specimen Collection",
   "fullPath": "ClinicalDocument/component/structuredBody/component/section/entry[templateId/@root='2.16.840.1.113883.3.3731.1.105.9']/act/entryRelationship/procedure[templateId/@root='2.16.840.1.113883.3.3731.1.105.10']/participant[@typeCode='PRD']/participantRole[@classCode='SPEC']/playingEntity/code",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CE",
   "valueSet": "VS-008",
   "source": "CS-D10 v4.9beta2 — Lab Result CDA 4.10",
   "notes": ""
  },
  {
   "elementId": "CDM-0019",
   "interfaceId": "IF-10",
   "localName": "Specimen Type",
   "parent": "Specimen",
   "fullPath": "Specimen.type",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CodeableConcept",
   "valueSet": "VS-008",
   "source": "FHIR Lab Order 27-01-2026 — Specimen (1.3.4)",
   "notes": "Specimen entry itself is R2 [0..*] in the bundle"
  },
  {
   "elementId": "CDM-0019",
   "interfaceId": "IF-11",
   "localName": "Specimen Type",
   "parent": "Specimen",
   "fullPath": "Specimen.type",
   "optionality": "M",
   "cardinality": "[1..1]",
   "dataType": "CodeableConcept",
   "valueSet": "VS-008",
   "source": "FHIR Lab Report 27-01-2026 — Specimen",
   "notes": ""
  },
  {
   "elementId": "CDM-0019",
   "interfaceId": "IF-14",
   "localName": "Specimen Type",
   "parent": "LaboratoryResultSpecimen",
   "fullPath": "LaboratoryResultSpecimen.specimenTypeId → LaboratorySpecimenType.code (+ description)",
   "optionality": "O",
   "cardinality": "0..1",
   "dataType": "FK / VARCHAR(50,200)",
   "valueSet": "VS-008",
   "source": "CDR Admin Manual v16 — Laboratory Results HDC (SPM-4)",
   "notes": ""
  },
  {
   "elementId": "CDM-0020",
   "interfaceId": "IF-08",
   "localName": "Prescribed Generic – Code",
   "parent": "Medication (contained)",
   "fullPath": "MedicationRequest.contained(Medication).code.coding",
   "optionality": "M (Generic) / NP (Compound)",
   "cardinality": "[1..1] / [0..0]",
   "dataType": "CodeableConcept",
   "valueSet": "VS-009",
   "source": "Med Use Case 06-05-2025 — Medication: Prescribed Generic",
   "notes": "code.text always M; via MedicationRequest.medicationReference"
  },
  {
   "elementId": "CDM-0020",
   "interfaceId": "IF-09",
   "localName": "Dispensed Medicinal Product – Code",
   "parent": "Medication (contained)",
   "fullPath": "MedicationDispense.contained(Medication).code.coding",
   "optionality": "M (Brand) / NP (Compound)",
   "cardinality": "[1..1] / [0..0]",
   "dataType": "CodeableConcept",
   "valueSet": "VS-009",
   "source": "Med Use Case 06-05-2025 — Medication: Dispensed Product",
   "notes": "Via MedicationDispense.medicationReference; lot/expiry in Medication.batch"
  }
 ],
 "valueSets": [
  {
   "id": "VS-001",
   "name": "CS-Adm-Gender",
   "displayName": "Gender",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.8.1",
   "csOid": "2.16.840.1.113883.3.3731.1.201.8",
   "binding": "Required",
   "totalCodes": 8,
   "description": "Biological sex of the person.",
   "status": "Draft"
  },
  {
   "id": "VS-002",
   "name": "CS-Adm-PatientClass",
   "displayName": "Patient Class",
   "vsOid": "2.16.840.1.113883.3.3731.1.203.33.1",
   "csOid": "2.16.840.1.113883.3.3731.1.203.33 / HL7 v2 patientClass 2.16.840.1.113883.18.5 / 2.16.840.1.113883.5.4",
   "binding": "Required",
   "totalCodes": 12,
   "description": "Categorization of patients by type of care or service received (v2 adds codes beyond HL7 E/I/O).",
   "status": "Draft"
  },
  {
   "id": "VS-003",
   "name": "CS-Adm-OrderPriority",
   "displayName": "KSA Lab Order Priority",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.1",
   "csOid": "2.16.840.1.113883.5.7 (HL7 Priority)",
   "binding": "Required",
   "totalCodes": 2,
   "description": "Level of urgency assigned to an order (A = ASAP, R = Routine).",
   "status": "Draft"
  },
  {
   "id": "VS-004",
   "name": "CS-Adm-OrderStatus",
   "displayName": "KSA Order Status",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.2",
   "csOid": "2.16.840.1.113883.5.14 (HL7 ActStatus)",
   "binding": "Required",
   "totalCodes": 6,
   "description": "Current state or progress of an order.",
   "status": "Draft"
  },
  {
   "id": "VS-005",
   "name": "CS-Adm-DiagnosticReportStatus",
   "displayName": "Nphies FHIR Diagnostic Report Status",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.27",
   "csOid": "2.16.840.1.113883.4.642.4.236 (FHIR diagnostic-report-status)",
   "binding": "Required",
   "totalCodes": 18,
   "description": "Current state or stage of a diagnostic report.",
   "status": "Draft"
  },
  {
   "id": "VS-006",
   "name": "CS-Obs-VitalSign",
   "displayName": "(Vital sign LOINC panel)",
   "vsOid": "2.16.840.1.113883.3.3731.1.203.45.1",
   "csOid": "2.16.840.1.113883.3.3731.1.203.45 / LOINC",
   "binding": "Required",
   "totalCodes": 28,
   "description": "Physiological parameters (LOINC codes) recorded to assess health status, with expected units.",
   "status": "Draft"
  },
  {
   "id": "VS-007",
   "name": "CS-Obs-ResultStatus",
   "displayName": "(Observation result status)",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.37.1",
   "csOid": "2.16.840.1.113883.3.3731.1.201.37",
   "binding": "Required",
   "totalCodes": 4,
   "description": "Observation result status codes used in OBX-11 (F/C/D/W).",
   "status": "Draft"
  },
  {
   "id": "VS-008",
   "name": "CS-Lab-SpecimenType",
   "displayName": "Specimen Type",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.5",
   "csOid": "2.16.840.1.113883.18.311 (HL7 v2 Table 0487) / SNOMED CT",
   "binding": "Required",
   "totalCodes": 1819,
   "description": "Kind of biological sample collected for lab testing. Full list in IS0200 tab CS-Lab-SpecimenType.",
   "status": "Draft"
  },
  {
   "id": "VS-009",
   "name": "CS-Med-SFDADrug",
   "displayName": "(SFDA drug list)",
   "vsOid": "2.16.840.1.113883.3.3731.1.208.25.1",
   "csOid": "2.16.840.1.113883.3.3731.1.208.25",
   "binding": "Required",
   "totalCodes": 8439,
   "description": "Medication items coded via SFDA's drug list (GTIN, generic, brand, strength). Full list in IS0200 tab CS-Med-SFDADrug.",
   "status": "Draft"
  },
  {
   "id": "VS-010",
   "name": "CS-Clinical-PrincipalDiagnosis",
   "displayName": "Principal Diagnosis (KSA)",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.22",
   "csOid": "2.16.840.1.113883.6.135 (ICD-10-AM)",
   "binding": "Required",
   "totalCodes": null,
   "description": "Main condition established as the primary reason for stay. ICD-10-AM (licensed — see IS0200 tab).",
   "status": "Draft"
  },
  {
   "id": "VS-011",
   "name": "CS-Lab-ObservationUnit",
   "displayName": "(Lab observation units)",
   "vsOid": "2.16.840.1.113883.3.3731.1.201.32.1",
   "csOid": "2.16.840.1.113883.6.8 (UCUM) / 2.16.840.1.113883.3.3731.1.201.32",
   "binding": "Required",
   "totalCodes": 902,
   "description": "Measurement units for observed lab values. Full list in IS0200 tab CS-Lab-ObservationUnit.",
   "status": "Draft"
  }
 ],
 "valueSetCodes": [
  {
   "valueSetId": "VS-001",
   "code": "M",
   "display": "Male",
   "note": "Sample — full set (8 codes) in IS0200 tab CS-Adm-Gender v1"
  },
  {
   "valueSetId": "VS-001",
   "code": "F",
   "display": "Female",
   "note": "Sample — full set (8 codes) in IS0200 tab CS-Adm-Gender v1"
  },
  {
   "valueSetId": "VS-001",
   "code": "N",
   "display": "Undifferentiated",
   "note": "Sample — full set (8 codes) in IS0200 tab CS-Adm-Gender v1"
  },
  {
   "valueSetId": "VS-001",
   "code": "U",
   "display": "Undetermined",
   "note": "Sample — full set (8 codes) in IS0200 tab CS-Adm-Gender v1"
  },
  {
   "valueSetId": "VS-002",
   "code": "E",
   "display": "Emergency",
   "note": "Sample — full set (12 codes) in IS0200 tab CS-Adm-PatientClass v2"
  },
  {
   "valueSetId": "VS-002",
   "code": "I",
   "display": "Inpatient",
   "note": "Sample — full set (12 codes) in IS0200 tab CS-Adm-PatientClass v2"
  },
  {
   "valueSetId": "VS-002",
   "code": "O",
   "display": "Outpatient",
   "note": "Sample — full set (12 codes) in IS0200 tab CS-Adm-PatientClass v2"
  },
  {
   "valueSetId": "VS-002",
   "code": "D",
   "display": "Inpatient Daycase",
   "note": "Sample — full set (12 codes) in IS0200 tab CS-Adm-PatientClass v2"
  },
  {
   "valueSetId": "VS-003",
   "code": "A",
   "display": "As Soon As Possible (ASAP)",
   "note": "Complete set — IS0200 tab CS-Adm-OrderPriority v1"
  },
  {
   "valueSetId": "VS-003",
   "code": "R",
   "display": "Routine",
   "note": "Complete set — IS0200 tab CS-Adm-OrderPriority v1"
  },
  {
   "valueSetId": "VS-004",
   "code": "aborted",
   "display": "Order was aborted",
   "note": "Sample — full set (6 codes) in IS0200 tab CS-Adm-OrderStatus v1"
  },
  {
   "valueSetId": "VS-004",
   "code": "active",
   "display": "Order is in process.",
   "note": "Sample — full set (6 codes) in IS0200 tab CS-Adm-OrderStatus v1"
  },
  {
   "valueSetId": "VS-004",
   "code": "canceled",
   "display": "Order was canceled",
   "note": "Sample — full set (6 codes) in IS0200 tab CS-Adm-OrderStatus v1"
  },
  {
   "valueSetId": "VS-004",
   "code": "completed",
   "display": "Order is completed.",
   "note": "Sample — full set (6 codes) in IS0200 tab CS-Adm-OrderStatus v1"
  },
  {
   "valueSetId": "VS-005",
   "code": "registered",
   "display": "Registered",
   "note": "Sample — full set (18 codes) in IS0200 tab CS-Adm-DiagnosticReportStatus v1"
  },
  {
   "valueSetId": "VS-005",
   "code": "partial",
   "display": "Partial",
   "note": "Sample — full set (18 codes) in IS0200 tab CS-Adm-DiagnosticReportStatus v1"
  },
  {
   "valueSetId": "VS-005",
   "code": "preliminary",
   "display": "Preliminary",
   "note": "Sample — full set (18 codes) in IS0200 tab CS-Adm-DiagnosticReportStatus v1"
  },
  {
   "valueSetId": "VS-005",
   "code": "final",
   "display": "Final",
   "note": "Sample — full set (18 codes) in IS0200 tab CS-Adm-DiagnosticReportStatus v1"
  },
  {
   "valueSetId": "VS-006",
   "code": "9279-1",
   "display": "RESPIRATION RATE (/min)",
   "note": "Sample — full set (28 LOINC codes with units) in IS0200 tab CS-Obs-VitalSign v1"
  },
  {
   "valueSetId": "VS-006",
   "code": "8867-4",
   "display": "HEART BEAT (/min)",
   "note": "Sample — full set (28 LOINC codes with units) in IS0200 tab CS-Obs-VitalSign v1"
  },
  {
   "valueSetId": "VS-006",
   "code": "2710-2",
   "display": "OXYGEN SATURATION (%)",
   "note": "Sample — full set (28 LOINC codes with units) in IS0200 tab CS-Obs-VitalSign v1"
  },
  {
   "valueSetId": "VS-006",
   "code": "8480-6",
   "display": "INTRAVASCULAR SYSTOLIC",
   "note": "Sample — full set (28 LOINC codes with units) in IS0200 tab CS-Obs-VitalSign v1"
  },
  {
   "valueSetId": "VS-007",
   "code": "F",
   "display": "Final results. Stored and verified; changed only via corrected result.",
   "note": "Complete set — IS0200 tab CS-Obs-ResultStatus v1"
  },
  {
   "valueSetId": "VS-007",
   "code": "C",
   "display": "Correction to results.",
   "note": "Complete set — IS0200 tab CS-Obs-ResultStatus v1"
  },
  {
   "valueSetId": "VS-007",
   "code": "D",
   "display": "Deletes the OBX record.",
   "note": "Complete set — IS0200 tab CS-Obs-ResultStatus v1"
  },
  {
   "valueSetId": "VS-007",
   "code": "W",
   "display": "Post original as wrong (e.g., wrong patient)",
   "note": "Complete set — IS0200 tab CS-Obs-ResultStatus v1"
  },
  {
   "valueSetId": "VS-008",
   "code": "116251003",
   "display": "Wick",
   "note": "Sample — full set (1,819 SNOMED CT codes) in IS0200 tab CS-Lab-SpecimenType v2"
  },
  {
   "valueSetId": "VS-008",
   "code": "414781009",
   "display": "Mucous membrane structure (body structure)",
   "note": "Sample — full set (1,819 SNOMED CT codes) in IS0200 tab CS-Lab-SpecimenType v2"
  },
  {
   "valueSetId": "VS-008",
   "code": "41329004",
   "display": "Polyp",
   "note": "Sample — full set (1,819 SNOMED CT codes) in IS0200 tab CS-Lab-SpecimenType v2"
  },
  {
   "valueSetId": "VS-008",
   "code": "79068005",
   "display": "Needle",
   "note": "Sample — full set (1,819 SNOMED CT codes) in IS0200 tab CS-Lab-SpecimenType v2"
  },
  {
   "valueSetId": "VS-009",
   "code": "00300020020232",
   "display": "TERIPARATIDE — FORTEO 20 MCG per 80MCL",
   "note": "Sample — full set (8,439 GTIN entries) in IS0200 tab CS-Med-SFDADrug v1"
  },
  {
   "valueSetId": "VS-009",
   "code": "06287046260191",
   "display": "LAMOTRIGINE — Lamotrine 50",
   "note": "Sample — full set (8,439 GTIN entries) in IS0200 tab CS-Med-SFDADrug v1"
  },
  {
   "valueSetId": "VS-009",
   "code": "06251106161377",
   "display": "VALSARTAN — DIOSTAR 80 mg film-coated tablet",
   "note": "Sample — full set (8,439 GTIN entries) in IS0200 tab CS-Med-SFDADrug v1"
  },
  {
   "valueSetId": "VS-010",
   "code": "(ICD-10-AM)",
   "display": "Refer to licensed ICD-10-AM & ACHI classification",
   "note": "Codes not enumerated in IS0200 (licensed)"
  },
  {
   "valueSetId": "VS-011",
   "code": "(UCUM)",
   "display": "Refer to IS0200 tab CS-Lab-ObservationUnit",
   "note": "Full set (902 codes) in IS0200 tab CS-Lab-ObservationUnit"
  }
 ]
}
```
